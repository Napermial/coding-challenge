from csv import reader, writer
import logging
from datetime import datetime
from pathlib import Path
from enum import IntEnum
from os import sep


class CsvStructure(IntEnum):
    """
    holds the positions of the columns and line length
    """
    SEARCH_TERM = 0
    CLICKS = 5
    CURRENCY = 6
    COST = 7
    IMPRESSIONS = 8
    CONVERSION_VALUE = 10
    LINE_LENGTH = 10


def read_file(file_path: str) -> ([], str):
    """
    reads csv and prepares data for writing out
    :param file_path: the path of the file
    :return: lines as a list and the currency
    """
    lines = []
    currency = ''
    with open(f"{file_path}", encoding="utf-16") as file:
        csv_reader = reader(file, delimiter='\t')
        next(csv_reader, None)
        for line in csv_reader:
            if currency == '':
                currency = line[CsvStructure.CURRENCY]
            if line[CsvStructure.CURRENCY] != currency:
                logging.error(
                    f'There are more than one currencies present in the file:' +
                    f' {line[CsvStructure.CURRENCY]} opposed to {currency}')
                break
            if len(line) < CsvStructure.LINE_LENGTH:
                logging.error(f"The line is shorter than expected, skipping: {line}")
                continue

            if line[CsvStructure.CONVERSION_VALUE] == '0':
                lines.append([line[CsvStructure.SEARCH_TERM], line[CsvStructure.CLICKS], line[CsvStructure.COST],
                              line[CsvStructure.IMPRESSIONS], line[CsvStructure.CONVERSION_VALUE], 0.0])
                continue
            try:
                lines.append(calculate_roas(line))
            except ValueError:
                logging.error(f"Couldn't convert cost or conversion value to number - skipping: {line}")
                continue
    return lines, currency


def calculate_roas(line) -> []:
    """
    calculates ROAS with casting cost and coversion value
    :param line: currently processed line
    :return: list of roas calculated line
    """
    cost = float(line[CsvStructure.COST])
    conversion_value = float(line[CsvStructure.CONVERSION_VALUE])
    return [line[CsvStructure.SEARCH_TERM], line[CsvStructure.CLICKS], line[CsvStructure.COST],
            line[CsvStructure.IMPRESSIONS], line[CsvStructure.CONVERSION_VALUE], cost / conversion_value]


def write_output(rows: [], currency: str, output_path: str):
    """
    writes the calculated roas to a csv file
    :param rows: the data
    :param currency: for the file structure
    :param output_path: where to create the file
    """
    headers = ["search_term", "clicks", "cost", "impressions", "conversion_value", "roas"]
    Path(f'{output_path.replace(sep, "/")}/processed/{currency}/search_terms/').mkdir(parents=True, exist_ok=True)
    with open(f'{output_path.replace(sep, "/")}/processed/{currency}/search_terms/{datetime.now().timestamp()}.csv',
              mode='w',
              encoding='utf-16') as f:
        csv_writer = writer(f, delimiter=';', lineterminator='\n')
        csv_writer.writerow(headers)
        csv_writer.writerows(rows)


def process_file(file_path, output_path):
    """
    reads the input csv file and writes an output csv file
    :param file_path: path of the input file
    :param output_path: path for the output file
    """
    rows, currency = read_file(file_path)
    write_output(rows, currency, output_path)
