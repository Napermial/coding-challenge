from queue import SimpleQueue
from os import cpu_count
from file_explorer import CheckFiles
from time import sleep
from concurrent.futures import ThreadPoolExecutor
from threading import Thread
import process_csv
from sys import argv


class TaskScheduler(Thread):
    """
    tracks new files and emits the found new files' path
    """
    def __init__(self, path, group=None, target=None, name=None,
                 args=(), kwargs=None, verbose=None):
        Thread.__init__(self, group, target, name, args, kwargs)
        if kwargs is None:
            kwargs = {}
        self.found_files = frozenset()
        self.path = path
        self.tasks = SimpleQueue()
        self._return = None

    def schedule_tasks(self) -> SimpleQueue:
        """
        runs file exproing function
        :return: queue of not yet processed files
        """
        sleep(60)
        tasks = SimpleQueue()
        file_checker = CheckFiles(found_files=self.found_files, path=self.path)
        file_checker.start()
        all_files = file_checker.join()
        newly_found = all_files.difference(self.found_files)
        for task in newly_found:
            tasks.put(f"{self.path}\\{task}")
        self.found_files = all_files
        return tasks

    def join(self, *args):
        Thread.join(self, *args)


def main():
    """
    starts a thread for file discovery and as many as there are cpu cores to process the found files
    """
    place = argv[1]
    output = argv[2]
    s = TaskScheduler(path=place)
    with ThreadPoolExecutor(cpu_count()) as ex:
        while True:
            tasks = s.schedule_tasks()
            while not tasks.empty():
                ex.submit(process_csv.process_file(tasks.get(), output))


if __name__ == '__main__':
    main()
