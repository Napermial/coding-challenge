from threading import Thread
from os.path import join, isfile
from os import listdir


def check_files(found_files: frozenset, path: str) -> frozenset:
    """
    static function to find all files in a dictionary
    :param found_files: the previously found files
    :param path: path of dictionary
    :return: found files as frozenset
    """
    files = set()
    for file in listdir(path):
        full_path = join(path, file)
        if isfile(full_path):
            files.add(file)
    return found_files.union(files)


class CheckFiles(Thread):
    """
    Finds new files - can be run as separate thread
    """
    def __init__(self, found_files : frozenset, path : str):
        Thread.__init__(self)
        self.found_files = found_files
        self.path = path
        self._return = None

    def run(self):
        self._return = check_files(self.found_files, self.path)

    def join(self, **kwargs) -> frozenset:
        """
        special join to retrieve the found paths
        :param kwargs:
        :return: found paths as frozenset
        """
        Thread.join(self)
        return self._return
