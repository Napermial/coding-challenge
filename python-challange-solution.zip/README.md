# Roas calculator daemon
This app watches a folder for new - unprocessed files and calculates their roas - outputting a csv file to the specified output directory.

## installing
- create a virtual environment - python3 -m venv /path/to/new/virtual/environment
- install dependencies from requirements.txt pip install -r requirements.txt

## running
- run with: pythonw.exe roas-calculator input_path(directory) output_path(directory)
pythonw starts without a terminal - daemonization libraries are only avalilable for unix
  
To stop the script the processes must be killed 